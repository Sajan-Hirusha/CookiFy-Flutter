package com.example.mealplanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
