import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(MealPlannerApp());
}

class MealPlannerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MealPlanner(),
    );
  }
}

class MealPlanner extends StatefulWidget {
  @override
  _MealPlannerState createState() => _MealPlannerState();
}

class _MealPlannerState extends State<MealPlanner> {
  final List<String> days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  String selectedDay = "Monday";
  String selectedMeal = "";
  final TextEditingController mealController = TextEditingController();

  Map<String, Map<String, String>> weeklyPlan = {};

  @override
  void initState() {
    super.initState();
    _loadWeeklyPlan();
  }

  Future<void> _loadWeeklyPlan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedData = prefs.getString('weeklyPlan');
    if (savedData != null) {
      setState(() {
        weeklyPlan = Map<String, Map<String, String>>.from(
          json.decode(savedData).map((key, value) => MapEntry(key, Map<String, String>.from(value))),
        );
      });
    }
  }

  Future<void> _saveWeeklyPlan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('weeklyPlan', json.encode(weeklyPlan));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Meal Planner",
          style: TextStyle(
            color: Colors.yellow, // Change the title color to yellow
          ),
        ),
        backgroundColor: Color(0xFF264F53),
        centerTitle: true, // Align the title to the center
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButton<String>(
              value: selectedDay,
              onChanged: (value) {
                setState(() {
                  selectedDay = value!;
                });
              },
              items: days.map((day) {
                return DropdownMenuItem(
                  value: day,
                  child: Text(day),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: ["Breakfast", "Lunch", "Snack", "Dinner"].map((meal) {
                return ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedMeal = meal;
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: selectedMeal == meal ? Colors.teal : Colors.grey,
                  ),
                  child: Text(meal),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            if (selectedMeal.isNotEmpty)
              Column(
                children: [
                  TextField(
                    controller: mealController,
                    decoration: InputDecoration(
                      labelText: "Enter $selectedMeal meal",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      setState(() {
                        weeklyPlan[selectedDay] ??= {};
                        weeklyPlan[selectedDay]![selectedMeal] = mealController.text;
                        mealController.clear();
                      });
                      await _saveWeeklyPlan();
                    },
                    child: Text("Save Meal"),
                  ),
                ],
              ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: weeklyPlan.entries.map((entry) {
                  return Card(
                    margin: EdgeInsets.all(8),
                    child: ListTile(
                      title: Text(entry.key),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: entry.value.entries.map((mealEntry) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("${mealEntry.key}: ${mealEntry.value}"),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () async {
                                  setState(() {
                                    entry.value.remove(mealEntry.key);
                                    if (entry.value.isEmpty) {
                                      weeklyPlan.remove(entry.key);
                                    }
                                  });
                                  await _saveWeeklyPlan();
                                },
                              ),
                            ],
                          );
                        }).toList(),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
